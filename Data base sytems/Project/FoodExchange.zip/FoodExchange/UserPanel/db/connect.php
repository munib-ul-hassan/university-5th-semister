<?php

// function connect(){
//     ob_start();
//     @session_start();
//     $con = mysqli_connect("localhost","thepakde_food_exchange","food_exchange123!@#","thepakde_food_exchange");
//     if(!$con) die("Unable to connect to MySQL: " . mysqli_error($con));
//     return $con;
//     // if($con){
//     //     echo '<script>alert("Connect")</script>';
//     // }
//     // else{
//     //     echo '<script>alert("not Connect")</script>';    
//     // } 
// }
// ob_start();
// ob_start();
@session_start();
$con = mysqli_connect("localhost","thepakde_food_exchange","food_exchange123!@#","thepakde_food_exchange");
// if($con){
//     echo '<script>alert("Connect")</script>';
// }
// else{
//     echo '<script>alert("not Connect")</script>';
// }


?>